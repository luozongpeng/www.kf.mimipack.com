<?php

$_CFG = array();
$_CFG['BaseUrl'] = "http://localhost/000/";
$_CFG['Actived'] = "1";
$_CFG['ColorStyle'] = "1";
$_CFG['Record'] = "10";
$_CFG['Lang'] = "Auto";
$_CFG['AuthUpload'] = "1";
$_CFG['AllowUploadFile'] = "0";
$_CFG['UploadLimit'] = "6";
$_CFG['AutoTrans'] = "1";
$_CFG['AutoOpen'] = "0";
$_CFG['Update'] = "2";
$_CFG['AutoOffline'] = "8";
$_CFG['KillRobotCode'] = "2T161F68";
$_CFG['Timezone'] = "+8";
$_CFG['DateFormat'] = "Y-m-d";
$_CFG['Title'] = "WeLive在线客服系统";
$_CFG['Welcome'] = "欢迎进入客服系统, 请咨询您的问题! 如果您不方便打字, 请直接拨打咨询电话: <font color='red'>800 - 800008</font>";
$_CFG['Welcome_en'] = "Welcome! please post your question... If you could not type, pls call <font color=red>800 - 800001</font>";
$_CFG['Comment_note'] = "<b>您还可以通知以下方式联系我们:</b><br>电话: <font color='red'>800 - 800008</font><br>Q Q: <font color='red'>66666666</font><br>Email: <font color='red'>xxx@xxxx.com</font>";
$_CFG['Comment_note_en'] = "<b>You can contact us as below:</b><br>Tel: <font color='red'>800 - 800008</font><br>QQ: <font color='red'>66666666</font><br>Email: <font color='red'>xxx@xxxx.com</font>";
$_CFG['Email'] = "xxxx@xxxxxx.com";
$_CFG['UseSmtp'] = "1";
$_CFG['SmtpHost'] = "smtp.163.com";
$_CFG['SmtpEmail'] = "xxxxxx@163.com";
$_CFG['SmtpPort'] = "25";
$_CFG['SmtpUser'] = "xxxxxxxx";
$_CFG['SmtpPassword'] = "xxxxxxxxx";
$_CFG['RobotName'] = "小来";
$_CFG['RobotName_en'] = "Lai Lai";
$_CFG['RobotPost'] = "智能机器人客服";
$_CFG['RobotPost_en'] = "Smart Robot Support";
$_CFG['SocketPort'] = "8420";
$_CFG['Is_Https'] = "0";
$_CFG['SSL_CrtPath'] = "";
$_CFG['SSL_KeyPath'] = "";
$_CFG['CDN_Domain'] = "";

?>