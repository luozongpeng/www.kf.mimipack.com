<?php
	$WeLiveVersion = '6.4.0';
?>